/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_385(unsigned *p)
{
    *p = 2881720408U;
}

void setval_352(unsigned *p)
{
    *p = 2488816601U;
}

void setval_363(unsigned *p)
{
    *p = 2428995656U;
}

void setval_318(unsigned *p)
{
    *p = 2425393240U;
}

unsigned addval_263(unsigned x)
{
    return x + 3347662941U;
}

unsigned addval_190(unsigned x)
{
    return x + 1002672728U;
}

void setval_277(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_247()
{
    return 3284633929U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_310(unsigned *p)
{
    *p = 3767101618U;
}

unsigned addval_307(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_448()
{
    return 2464188744U;
}

void setval_159(unsigned *p)
{
    *p = 3402193062U;
}

void setval_254(unsigned *p)
{
    *p = 3286272344U;
}

unsigned addval_463(unsigned x)
{
    return x + 3375945385U;
}

unsigned getval_388()
{
    return 3677932169U;
}

unsigned addval_217(unsigned x)
{
    return x + 3286272328U;
}

void setval_285(unsigned *p)
{
    *p = 3529558665U;
}

unsigned addval_373(unsigned x)
{
    return x + 2425411241U;
}

unsigned getval_365()
{
    return 3523794569U;
}

unsigned getval_209()
{
    return 3281049289U;
}

unsigned addval_486(unsigned x)
{
    return x + 3525362089U;
}

unsigned addval_204(unsigned x)
{
    return x + 2428602766U;
}

void setval_478(unsigned *p)
{
    *p = 3526934985U;
}

unsigned addval_264(unsigned x)
{
    return x + 2425411209U;
}

void setval_237(unsigned *p)
{
    *p = 2425408009U;
}

void setval_441(unsigned *p)
{
    *p = 3524837769U;
}

void setval_295(unsigned *p)
{
    *p = 3526934921U;
}

unsigned addval_135(unsigned x)
{
    return x + 3286276424U;
}

unsigned addval_472(unsigned x)
{
    return x + 1942211208U;
}

void setval_466(unsigned *p)
{
    *p = 3232028297U;
}

unsigned addval_262(unsigned x)
{
    return x + 3380926081U;
}

unsigned getval_183()
{
    return 3526937241U;
}

unsigned getval_260()
{
    return 2430634313U;
}

unsigned getval_405()
{
    return 1170459273U;
}

void setval_474(unsigned *p)
{
    *p = 3373842825U;
}

unsigned addval_231(unsigned x)
{
    return x + 3372794251U;
}

void setval_205(unsigned *p)
{
    *p = 3375417993U;
}

void setval_414(unsigned *p)
{
    *p = 2446756250U;
}

unsigned addval_218(unsigned x)
{
    return x + 3227566473U;
}

unsigned getval_175()
{
    return 3767093749U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
