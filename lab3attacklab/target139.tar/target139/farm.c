/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_143()
{
    return 2425393240U;
}

unsigned getval_413()
{
    return 2421732624U;
}

void setval_458(unsigned *p)
{
    *p = 3281031248U;
}

unsigned addval_418(unsigned x)
{
    return x + 3347662864U;
}

unsigned getval_181()
{
    return 3351742792U;
}

void setval_227(unsigned *p)
{
    *p = 2445773128U;
}

unsigned getval_376()
{
    return 3284633928U;
}

unsigned addval_259(unsigned x)
{
    return x + 3809264408U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_165(unsigned *p)
{
    *p = 3674787465U;
}

unsigned addval_131(unsigned x)
{
    return x + 2430638408U;
}

unsigned addval_169(unsigned x)
{
    return x + 3224948361U;
}

void setval_435(unsigned *p)
{
    *p = 2428668922U;
}

unsigned addval_403(unsigned x)
{
    return x + 3286280520U;
}

unsigned getval_214()
{
    return 3380924809U;
}

void setval_113(unsigned *p)
{
    *p = 2429471223U;
}

unsigned getval_348()
{
    return 3223376137U;
}

void setval_194(unsigned *p)
{
    *p = 3374370313U;
}

unsigned addval_383(unsigned x)
{
    return x + 3675836041U;
}

unsigned getval_466()
{
    return 3286272456U;
}

unsigned addval_202(unsigned x)
{
    return x + 3375940235U;
}

unsigned addval_388(unsigned x)
{
    return x + 3677930121U;
}

unsigned addval_379(unsigned x)
{
    return x + 3286276424U;
}

unsigned addval_411(unsigned x)
{
    return x + 3677933977U;
}

unsigned getval_323()
{
    return 3373843081U;
}

unsigned addval_377(unsigned x)
{
    return x + 3286272328U;
}

void setval_374(unsigned *p)
{
    *p = 3223375529U;
}

void setval_110(unsigned *p)
{
    *p = 3525366153U;
}

unsigned getval_237()
{
    return 3767093334U;
}

void setval_367(unsigned *p)
{
    *p = 3252717896U;
}

void setval_404(unsigned *p)
{
    *p = 3674263177U;
}

unsigned addval_204(unsigned x)
{
    return x + 2425406153U;
}

unsigned getval_300()
{
    return 3285289042U;
}

void setval_256(unsigned *p)
{
    *p = 2430634344U;
}

unsigned addval_328(unsigned x)
{
    return x + 3374895497U;
}

unsigned addval_314(unsigned x)
{
    return x + 3221275273U;
}

void setval_478(unsigned *p)
{
    *p = 2425672073U;
}

unsigned getval_395()
{
    return 2428684764U;
}

void setval_463(unsigned *p)
{
    *p = 2425409928U;
}

unsigned getval_317()
{
    return 3263765655U;
}

void setval_425(unsigned *p)
{
    *p = 3526938241U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
